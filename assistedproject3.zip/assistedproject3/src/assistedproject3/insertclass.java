package assistedproject3;

public class insertclass {

}
