package assistedproject3;

public class selectquerydemo {

}
