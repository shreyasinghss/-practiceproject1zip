package corejava;

public class whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int count = 1;
		while(count <= 10) {
			System.out.println(count);
			count++;
			
		}
	}

}
