package corejava;

public class catchblock {

	
    public static void main(String[] args) {
        int[] numbers = { 1, 2, 3, 4, 5 };
        int index = 10;

        try {
            int result = numbers[index];
            System.out.println("The value at index " + index + " is: " + result);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Oops! Array index is out of bounds: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Oops! An error occurred: " + e.getMessage());
        }
    }
}


