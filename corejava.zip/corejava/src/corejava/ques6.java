package corejava;

public class ques6 {
	
	  int userage;
	  String username;
	
	  public ques6(int age, String name) {
		  userage = age;
		  username = name;
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   ques6 obj = new ques6(23, "shreya");
		    System.out.println(obj.userage + " " + obj.username);
	    
	}

}
