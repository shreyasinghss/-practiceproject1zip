package corejava;

public class throwskeyword {


	    public static void main(String[] args) {
	        try {
	            divide(10, 0);
	        } catch (ArithmeticException e) {
	            System.out.println("Oops! An error occurred: " + e.getMessage());
	        }
	    }

	    public static int divide(int dividend, int divisor) throws ArithmeticException {
	        if (divisor == 0) {
	            throw new ArithmeticException("Cannot divide by zero");
	        }
	        return dividend / divisor;
	    }
	}
