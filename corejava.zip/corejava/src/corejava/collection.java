package corejava;

import java.util.ArrayList;
import java.util.Collection;

public class collection {
    public static void main(String[] args) {
        // Create a new collection
        Collection<String> myCollection = new ArrayList<>();

        // Add elements to the collection
        myCollection.add("Apple");
        myCollection.add("Banana");
        myCollection.add("Orange");

        // Print the collection
        System.out.println("Elements in the collection: " + myCollection);

        // Check if the collection contains a specific element
        System.out.println("Does the collection contain 'Banana'? " + myCollection.contains("Banana"));

        // Remove an element from the collection
        myCollection.remove("Apple");

        // Print the updated collection
        System.out.println("Elements in the collection after removing 'Apple': " + myCollection);

        // Check if the collection is empty
        System.out.println("Is the collection empty? " + myCollection.isEmpty());

        // Get the size of the collection
        System.out.println("Size of the collection: " + myCollection.size());
    }
}


   