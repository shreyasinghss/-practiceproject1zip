package corejava;

public class tryblock {

    public static void main(String[] args) {
        int dividend = 10;
        int divisor = 2;
        
        try {
            divide(dividend, divisor);
        } catch (ArithmeticException e) {
            System.out.println("Oops! An error occurred: " + e.getMessage());
        }
    }

    public static void divide(int dividend, int divisor) {
        if (divisor == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        int result = dividend / divisor;
        System.out.println("The result of the division is: " + result);
    }
}
