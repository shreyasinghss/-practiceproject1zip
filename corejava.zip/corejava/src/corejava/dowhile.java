package corejava;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int count = 1;
		do {
			System.out.println("this is iteration " +count);
			count++;
			
		}
		while(count<=20);
		
	}

}
