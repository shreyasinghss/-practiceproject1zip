package corejava;

public class trycatchblock {
	
	    public static void main(String[] args) {
	        try {
	            int[] numbers = {1, 2, 3};
	            System.out.println(numbers[2]); // Trying to access an index that doesn't exist
	        } catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("An exception occurred: " + e.getMessage());
	        }
	    }
	}


