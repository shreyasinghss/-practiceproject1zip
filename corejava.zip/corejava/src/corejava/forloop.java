package corejava;

public class forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int count= 1;count<=20;count++)
		{
			System.out.println("this is iteration" + count);
		
		}
	}

}
