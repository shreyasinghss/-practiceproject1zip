package corejava;

public class inheritance {

	  protected String  username = shreya;
	
	public void login() {
		 System.out.println("Please enter valid cradentials");
	}
}
	class inherit extends inheritance {
		
     private int userid = 1243;
	
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		inherit obj3 = new inherit(); {
			obj3.login();
			  System.out.println(obj3.username+ " " + obj3.userid);
			
		
		}
	}

}
