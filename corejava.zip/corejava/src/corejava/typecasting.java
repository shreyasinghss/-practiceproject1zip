package corejava;

public class typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	// implicit type casting 
		
		int a = 10;        // bytes 4
		double b = a;       // bytes 8
		
		System.out.println(b);
		
		
		// explicit type casting 
		
		double x = 10.5 ;      //bytes 8 
		int y = (int) x;       // for converting the data type 
		
		System.out.println(x);
	}

}
