package corejava;

public class finallyblock {
	
    public static void main(String[] args) {
        try {
            // Code that may throw an exception
            int result = divide(10, 0);
            System.out.println("The result is: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Oops! An error occurred: " + e.getMessage());
        } finally {
            // Code that always executes, regardless of whether an exception occurred or not
            System.out.println("Finally block executed");
        }
    }

    public static int divide(int dividend, int divisor) {
        if (divisor == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return dividend / divisor;
    }
}



