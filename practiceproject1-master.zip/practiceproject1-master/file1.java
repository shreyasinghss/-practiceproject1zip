hello i am reading file1.java
