hello 
i am reading file3.cpp
